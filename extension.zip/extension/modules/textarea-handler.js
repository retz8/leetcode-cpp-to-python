// =============================================================================
// Textarea Handler - Manages textarea element replacement
// =============================================================================

window.TextareaHandler = class TextareaHandler {
  constructor(selectors) {
    this.selectors = selectors;
    this.originalValue = null;
  }

  /**
   * Update the existing textarea value to Python code.
   *
   * Important: On GitHub blob pages, this textarea is managed by GitHub/React.
   * Replacing the DOM node can break internal refs/layout and cause rendering
   * glitches (e.g., code area not showing). So we mutate in-place.
   */
  replaceWithPython(pythonCode) {
    const textarea = document.querySelector(this.selectors.codeTextarea);
    if (!textarea) {
      console.warn("[Lens] Textarea not found for replacement");
      return null;
    }

    if (this.originalValue === null) {
      this.originalValue = textarea.value;
    }

    textarea.value = pythonCode;
    textarea.textContent = pythonCode;

    console.log(
      "[Lens] Textarea value updated with Python code, length:",
      pythonCode.length
    );

    return this.originalValue;
  }

  /**
   * Restore original textarea value
   */
  restore() {
    if (this.originalValue === null) {
      return;
    }

    const textarea = document.querySelector(this.selectors.codeTextarea);
    if (!textarea) {
      console.warn("[Lens] Textarea not found for restore");
      this.originalValue = null;
      return;
    }

    textarea.value = this.originalValue;
    textarea.textContent = this.originalValue;
    this.originalValue = null;

    console.log("[Lens] Original textarea value restored");
  }

  /**
   * Reset state
   */
  reset() {
    this.originalValue = null;
  }
};
