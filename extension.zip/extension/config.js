// Configuration for the Chrome Extension
const CONFIG = {
  // NOTE: 사지방 dev env is based on vscode tunnel
  BACKEND_URL: "https://vnw20xbg-8080.asse.devtunnels.ms",
  API_ENDPOINTS: {
    CONVERT: "/convert",
    HEALTH: "/health",
  },
};

// Make it available globally for both content scripts and service workers
if (typeof window !== "undefined") {
  window.CONFIG = CONFIG;
}

// Load modules as global scripts
(function () {
  const modules = [
    "modules/dom-helpers.js",
    "modules/textarea-handler.js",
    "modules/event-handlers.js",
    "content.js",
  ];

  function loadNextModule(index) {
    if (index >= modules.length) {
      return;
    }

    const script = document.createElement("script");
    script.src = chrome.runtime.getURL(modules[index]);
    script.onload = function () {
      loadNextModule(index + 1);
    };
    script.onerror = function () {
      console.error("[Lens] Failed to load:", modules[index]);
      loadNextModule(index + 1);
    };
    document.head.appendChild(script);
  }

  // Start loading when DOM is ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => loadNextModule(0));
  } else {
    loadNextModule(0);
  }
})();
