// =============================================================================
// LeetCode C++ to Python Lens - Content Script
// =============================================================================
// This script provides a seamless "lens" experience that replaces C++ code
// with Python translations directly in the GitHub DOM, enabling proper
// copy/paste, text selection, and Ctrl+F search on the converted code.
// =============================================================================

(function () {
  "use strict";

  // ===========================================================================
  // CONFIGURATION
  // ===========================================================================
  const LENS_CONFIG = {
    // Styling for converted Python code
    pythonColor: "#2563eb", // Blue color for Python text
    buttonActiveColor: "#16a34a", // Green when lens is active
    buttonInactiveColor: "#2563eb", // Blue when lens is inactive

    // Selectors for GitHub's code view (React-based new UI)
    selectors: {
      // Primary code source (hidden textarea with full file content)
      codeTextarea: '#read-only-cursor-text-area[aria-label="file content"]',

      // Rendered code lines (new React view)
      reactLineContents: ".react-code-line-contents-no-virtualization",
      reactLineById: '[id^="LC"]',
      reactCodeContainer: ".react-code-lines",
      reactBlobCode: '[data-testid="blob-code"]',

      // Legacy selectors (old GitHub view)
      legacyBlobCode: ".blob-wrapper table td.blob-code",
      legacyBlobPre: ".blob-wrapper pre",

      // Line number elements
      reactLineNumber: ".react-line-number",
      legacyLineNumber: ".blob-num",
    },

    // File extensions to activate on
    supportedExtensions: [".cpp", ".cc", ".cxx", ".hpp", ".h"],
  };

  // ===========================================================================
  // LENS STATE
  // ===========================================================================
  const lensState = {
    active: false,
    pythonLines: [],
    pythonFullCode: "",
    originalContent: new Map(), // Map<Element, {html, lineNum}>
    originalTextareaValue: "",
    observer: null,
    button: null,
    isConverting: false,
  };

  // ===========================================================================
  // UTILITY FUNCTIONS
  // ===========================================================================

  /**
   * Escape HTML special characters to prevent XSS
   */
  function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }

  /**
   * Check if current page is a C++ file on GitHub
   */
  function isCppFile() {
    const path = window.location.pathname;
    return LENS_CONFIG.supportedExtensions.some((ext) =>
      path.toLowerCase().endsWith(ext)
    );
  }

  /**
   * Check if we're on a GitHub blob (file view) page
   */
  function isGitHubBlobPage() {
    return (
      window.location.hostname === "github.com" &&
      window.location.pathname.includes("/blob/")
    );
  }

  /**
   * Get line number from a code line element
   */
  function getLineNumber(el) {
    // Method 1: id="LC1", id="LC2", etc.
    if (el.id) {
      const idMatch = el.id.match(/^LC(\d+)$/);
      if (idMatch) return parseInt(idMatch[1], 10);
    }

    // Method 2: data-line-number attribute on element or parent
    if (el.dataset?.lineNumber) {
      return parseInt(el.dataset.lineNumber, 10);
    }
    const rowWithData = el.closest("[data-line-number]");
    if (rowWithData) {
      return parseInt(rowWithData.dataset.lineNumber, 10);
    }

    // Method 3: Find sibling/parent line number element (React view)
    const parentRow = el.closest(".react-code-line");
    if (parentRow) {
      const lineNumEl = parentRow.querySelector(
        LENS_CONFIG.selectors.reactLineNumber
      );
      if (lineNumEl) {
        return parseInt(lineNumEl.textContent, 10);
      }
    }

    // Method 4: Table row structure (legacy view)
    const tableRow = el.closest("tr");
    if (tableRow) {
      const lineNumCell = tableRow.querySelector(
        LENS_CONFIG.selectors.legacyLineNumber
      );
      if (lineNumCell) {
        const num = parseInt(lineNumCell.textContent || lineNumCell.dataset?.lineNumber, 10);
        if (!isNaN(num)) return num;
      }
    }

    // Method 5: Count position among siblings
    const parent = el.parentElement;
    if (parent) {
      const siblings = Array.from(parent.children);
      const index = siblings.indexOf(el);
      if (index !== -1) return index + 1;
    }

    return null;
  }

  /**
   * Extract C++ code from the page
   */
  function extractCppCode() {
    // Method 1: Hidden textarea (most reliable for React view)
    const textarea = document.querySelector(LENS_CONFIG.selectors.codeTextarea);
    if (textarea && textarea.value) {
      return textarea.value;
    }

    // Method 2: Collect from rendered line elements
    const lineSelectors = [
      LENS_CONFIG.selectors.reactLineContents,
      LENS_CONFIG.selectors.reactLineById,
      LENS_CONFIG.selectors.legacyBlobCode,
    ];

    for (const selector of lineSelectors) {
      const lines = document.querySelectorAll(selector);
      if (lines.length > 0) {
        return Array.from(lines)
          .map((el) => el.textContent)
          .join("\n");
      }
    }

    // Method 3: Pre block (legacy)
    const preBlock = document.querySelector(LENS_CONFIG.selectors.legacyBlobPre);
    if (preBlock) {
      return preBlock.textContent;
    }

    return null;
  }

  /**
   * Get all code line elements currently in the DOM
   */
  function getCodeLineElements() {
    // Try React view selectors first
    let elements = document.querySelectorAll(
      LENS_CONFIG.selectors.reactLineContents
    );
    if (elements.length > 0) return elements;

    elements = document.querySelectorAll(LENS_CONFIG.selectors.reactLineById);
    if (elements.length > 0) return elements;

    // Try legacy view
    elements = document.querySelectorAll(LENS_CONFIG.selectors.legacyBlobCode);
    if (elements.length > 0) return elements;

    return [];
  }

  /**
   * Get the code container element for MutationObserver
   */
  function getCodeContainer() {
    return (
      document.querySelector(LENS_CONFIG.selectors.reactBlobCode) ||
      document.querySelector(LENS_CONFIG.selectors.reactCodeContainer) ||
      document.querySelector(".blob-wrapper")
    );
  }

  // ===========================================================================
  // LENS CORE FUNCTIONS
  // ===========================================================================

  /**
   * Apply lens to all visible code lines
   */
  function applyLensToLines() {
    if (!lensState.active || lensState.pythonLines.length === 0) return;

    const lineElements = getCodeLineElements();

    lineElements.forEach((el) => {
      // Skip if already processed
      if (el.hasAttribute("data-lens-applied")) return;

      const lineNum = getLineNumber(el);
      if (lineNum === null || lineNum < 1) return;

      // Store original content if not already stored
      if (!lensState.originalContent.has(el)) {
        lensState.originalContent.set(el, {
          html: el.innerHTML,
          lineNum: lineNum,
        });
      }

      // Get corresponding Python line (0-indexed)
      const pythonLine = lensState.pythonLines[lineNum - 1];
      const displayText = pythonLine !== undefined ? pythonLine : "";

      // Replace content with Python text
      el.innerHTML = `<span class="lens-python-text" style="color: ${LENS_CONFIG.pythonColor};">${escapeHtml(displayText)}</span>`;
      el.setAttribute("data-lens-applied", "true");
    });
  }

  /**
   * Update the hidden textarea with Python code
   */
  function updateTextareaContent(pythonCode) {
    const textarea = document.querySelector(LENS_CONFIG.selectors.codeTextarea);
    if (textarea) {
      if (!lensState.originalTextareaValue) {
        lensState.originalTextareaValue = textarea.value;
      }
      textarea.value = pythonCode;
    }
  }

  /**
   * Restore the hidden textarea to original content
   */
  function restoreTextareaContent() {
    const textarea = document.querySelector(LENS_CONFIG.selectors.codeTextarea);
    if (textarea && lensState.originalTextareaValue) {
      textarea.value = lensState.originalTextareaValue;
    }
  }

  /**
   * Activate the lens with Python code
   */
  function activateLens(pythonCode, pythonLines) {
    lensState.active = true;
    lensState.pythonFullCode = pythonCode;
    lensState.pythonLines = pythonLines;

    // Apply lens to current visible lines
    applyLensToLines();

    // Update textarea for copy operations
    updateTextareaContent(pythonCode);

    // Set up MutationObserver to handle GitHub's virtualized scrolling
    setupMutationObserver();

    // Update button state
    updateButtonState();

    console.log("[Lens] Activated - Python code applied to DOM");
  }

  /**
   * Deactivate the lens and restore original content
   */
  function deactivateLens() {
    lensState.active = false;

    // Disconnect observer
    if (lensState.observer) {
      lensState.observer.disconnect();
      lensState.observer = null;
    }

    // Restore all original content
    lensState.originalContent.forEach((data, el) => {
      if (el.isConnected) {
        el.innerHTML = data.html;
        el.removeAttribute("data-lens-applied");
      }
    });

    // Restore textarea
    restoreTextareaContent();

    // Clear state but keep pythonLines for potential re-activation
    lensState.originalContent.clear();
    lensState.originalTextareaValue = "";

    // Update button state
    updateButtonState();

    console.log("[Lens] Deactivated - Original C++ code restored");
  }

  /**
   * Set up MutationObserver to handle dynamic DOM changes
   * GitHub uses virtualized scrolling - lines are added/removed as you scroll
   */
  function setupMutationObserver() {
    if (lensState.observer) {
      lensState.observer.disconnect();
    }

    const container = getCodeContainer();
    if (!container) {
      console.warn("[Lens] Could not find code container for observer");
      return;
    }

    lensState.observer = new MutationObserver((mutations) => {
      if (!lensState.active) return;

      // Check if new nodes were added
      let hasNewNodes = false;
      for (const mutation of mutations) {
        if (mutation.addedNodes.length > 0) {
          hasNewNodes = true;
          break;
        }
      }

      if (hasNewNodes) {
        // Debounce to avoid excessive processing
        requestAnimationFrame(() => {
          applyLensToLines();
        });
      }
    });

    lensState.observer.observe(container, {
      childList: true,
      subtree: true,
    });

    console.log("[Lens] MutationObserver set up on code container");
  }

  // ===========================================================================
  // BACKEND COMMUNICATION
  // ===========================================================================

  /**
   * Send C++ code to backend for conversion via background script
   */
  async function convertCode(cppCode) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { type: "CONVERT_CODE", code: cppCode },
        (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          if (response && response.success) {
            resolve({
              python: response.python,
              lines: response.lines,
            });
          } else {
            reject(new Error(response?.error || "Conversion failed"));
          }
        }
      );
    });
  }

  // ===========================================================================
  // UI COMPONENTS
  // ===========================================================================

  /**
   * Update button appearance based on lens state
   */
  function updateButtonState() {
    if (!lensState.button) return;

    if (lensState.isConverting) {
      lensState.button.textContent = "Converting...";
      lensState.button.disabled = true;
      lensState.button.style.backgroundColor = "#9ca3af";
      lensState.button.style.cursor = "wait";
    } else if (lensState.active) {
      lensState.button.textContent = "Show Original (C++)";
      lensState.button.disabled = false;
      lensState.button.style.backgroundColor = LENS_CONFIG.buttonActiveColor;
      lensState.button.style.cursor = "pointer";
    } else {
      lensState.button.textContent = "Convert to Python";
      lensState.button.disabled = false;
      lensState.button.style.backgroundColor = LENS_CONFIG.buttonInactiveColor;
      lensState.button.style.cursor = "pointer";
    }
  }

  /**
   * Handle button click - toggle lens on/off
   */
  async function handleButtonClick() {
    if (lensState.isConverting) return;

    if (lensState.active) {
      // Deactivate lens
      deactivateLens();
    } else {
      // Activate lens
      if (lensState.pythonLines.length > 0) {
        // Already have converted code, just reactivate
        activateLens(lensState.pythonFullCode, lensState.pythonLines);
      } else {
        // Need to fetch conversion from backend
        const cppCode = extractCppCode();
        if (!cppCode) {
          console.error("[Lens] Could not extract C++ code from page");
          alert("Could not extract code from this page.");
          return;
        }

        lensState.isConverting = true;
        updateButtonState();

        try {
          const result = await convertCode(cppCode);
          lensState.isConverting = false;
          activateLens(result.python, result.lines);
        } catch (error) {
          lensState.isConverting = false;
          updateButtonState();
          console.error("[Lens] Conversion error:", error);
          alert(`Conversion failed: ${error.message}`);
        }
      }
    }
  }

  /**
   * Create and inject the floating toggle button
   */
  function createButton() {
    // Remove existing button if any
    const existing = document.getElementById("lens-toggle-button");
    if (existing) {
      existing.remove();
    }

    const button = document.createElement("button");
    button.id = "lens-toggle-button";
    button.textContent = "Convert to Python";

    // Apply styles
    Object.assign(button.style, {
      position: "fixed",
      bottom: "20px",
      right: "20px",
      zIndex: "10000",
      padding: "12px 20px",
      backgroundColor: LENS_CONFIG.buttonInactiveColor,
      color: "white",
      border: "none",
      borderRadius: "8px",
      fontSize: "14px",
      fontWeight: "600",
      cursor: "pointer",
      boxShadow: "0 4px 12px rgba(0, 0, 0, 0.15)",
      transition: "all 0.2s ease",
      fontFamily:
        '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    });

    // Hover effects
    button.addEventListener("mouseenter", () => {
      if (!lensState.isConverting) {
        button.style.transform = "translateY(-2px)";
        button.style.boxShadow = "0 6px 16px rgba(0, 0, 0, 0.2)";
      }
    });

    button.addEventListener("mouseleave", () => {
      button.style.transform = "translateY(0)";
      button.style.boxShadow = "0 4px 12px rgba(0, 0, 0, 0.15)";
    });

    // Click handler
    button.addEventListener("click", handleButtonClick);

    document.body.appendChild(button);
    lensState.button = button;

    console.log("[Lens] Toggle button created");
  }

  // ===========================================================================
  // NAVIGATION HANDLING
  // ===========================================================================

  /**
   * Reset lens state (used when navigating to a new page)
   */
  function resetLensState() {
    if (lensState.active) {
      deactivateLens();
    }
    lensState.pythonLines = [];
    lensState.pythonFullCode = "";
    lensState.originalContent.clear();
    lensState.originalTextareaValue = "";
  }

  /**
   * Initialize or re-initialize the lens for the current page
   */
  function initializeLens() {
    // Reset any existing state
    resetLensState();

    // Check if this is a supported page
    if (!isGitHubBlobPage() || !isCppFile()) {
      // Remove button if it exists
      if (lensState.button) {
        lensState.button.remove();
        lensState.button = null;
      }
      return;
    }

    // Create button if needed
    if (!lensState.button || !lensState.button.isConnected) {
      createButton();
    }

    updateButtonState();
    console.log("[Lens] Initialized for C++ file");
  }

  /**
   * Set up navigation detection for GitHub's SPA
   */
  function setupNavigationDetection() {
    // GitHub uses History API for navigation
    let lastUrl = window.location.href;

    // Check for URL changes periodically (handles all navigation types)
    setInterval(() => {
      if (window.location.href !== lastUrl) {
        lastUrl = window.location.href;
        console.log("[Lens] Navigation detected, reinitializing...");
        // Wait for DOM to settle
        setTimeout(initializeLens, 500);
      }
    }, 500);

    // Also listen for popstate (back/forward buttons)
    window.addEventListener("popstate", () => {
      setTimeout(initializeLens, 500);
    });

    // Listen for turbo navigation events (GitHub uses Turbo)
    document.addEventListener("turbo:load", () => {
      setTimeout(initializeLens, 100);
    });

    document.addEventListener("turbo:render", () => {
      setTimeout(initializeLens, 100);
    });
  }

  // ===========================================================================
  // KEYBOARD SHORTCUTS
  // ===========================================================================

  /**
   * Set up keyboard shortcuts
   */
  function setupKeyboardShortcuts() {
    document.addEventListener("keydown", (e) => {
      // Alt+P to toggle lens
      if (e.altKey && e.key.toLowerCase() === "p") {
        e.preventDefault();
        if (lensState.button && isGitHubBlobPage() && isCppFile()) {
          handleButtonClick();
        }
      }
    });
  }

  // ===========================================================================
  // MAIN INITIALIZATION
  // ===========================================================================

  function main() {
    console.log("[Lens] C++ to Python Lens extension loaded");

    // Initial setup
    initializeLens();

    // Set up navigation detection for GitHub SPA
    setupNavigationDetection();

    // Set up keyboard shortcuts
    setupKeyboardShortcuts();
  }

  // Run when DOM is ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", main);
  } else {
    main();
  }
})();