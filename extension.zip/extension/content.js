// =============================================================================
// LeetCode C++ to Python Lens - Content Script
// =============================================================================
// This script provides a seamless "lens" experience that replaces C++ code
// with Python translations directly in the GitHub DOM, enabling proper
// copy/paste, text selection, and Ctrl+F search on the converted code.
// =============================================================================

(function () {
  "use strict";

  // ===========================================================================
  // CONFIGURATION
  // ===========================================================================
  const LENS_CONFIG = {
    // Styling for converted Python code
    pythonColor: "#2563eb", // Blue color for Python text
    buttonActiveColor: "#16a34a", // Green when lens is active
    buttonInactiveColor: "#2563eb", // Blue when lens is inactive

    // Selectors for GitHub's code view (React-based new UI)
    selectors: {
      // Primary code source (hidden textarea with full file content)
      codeTextarea: '#read-only-cursor-text-area[aria-label="file content"]',

      // Rendered code lines (new React view)
      reactLineContents: ".react-code-line-contents-no-virtualization",
      reactLineById: '[id^="LC"]',
      reactCodeContainer: ".react-code-lines",
      reactBlobCode: '[data-testid="blob-code"]',

      // Legacy selectors (old GitHub view)
      legacyBlobCode: ".blob-wrapper table td.blob-code",
      legacyBlobPre: ".blob-wrapper pre",

      // Line number elements
      reactLineNumber: ".react-line-number",
      legacyLineNumber: ".blob-num",
    },

    // File extensions to activate on
    supportedExtensions: [".cpp", ".cc", ".cxx", ".hpp", ".h"],
  };

  // ===========================================================================
  // LENS STATE
  // ===========================================================================
  const lensState = {
    active: false,
    pythonLines: [],
    pythonFullCode: "",
    originalContent: new Map(), // Map<Element, {html, lineNum}>
    originalTextareaValue: "",
    originalTextareaStyles: null, // Store original textarea styles
    observer: null,
    button: null,
    isConverting: false,
  };

  // ===========================================================================
  // UTILITY FUNCTIONS
  // ===========================================================================

  /**
   * Escape HTML special characters to prevent XSS
   */
  function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }

  /**
   * Check if current page is a C++ file on GitHub
   */
  function isCppFile() {
    const path = window.location.pathname;
    return LENS_CONFIG.supportedExtensions.some((ext) =>
      path.toLowerCase().endsWith(ext)
    );
  }

  /**
   * Check if we're on a GitHub blob (file view) page
   */
  function isGitHubBlobPage() {
    return (
      window.location.hostname === "github.com" &&
      window.location.pathname.includes("/blob/")
    );
  }

  /**
   * Get line number from a code line element
   */
  function getLineNumber(el) {
    // Method 1: id="LC1", id="LC2", etc.
    if (el.id) {
      const idMatch = el.id.match(/^LC(\d+)$/);
      if (idMatch) return parseInt(idMatch[1], 10);
    }

    // Method 2: data-line-number attribute on element or parent
    if (el.dataset?.lineNumber) {
      return parseInt(el.dataset.lineNumber, 10);
    }
    const rowWithData = el.closest("[data-line-number]");
    if (rowWithData) {
      return parseInt(rowWithData.dataset.lineNumber, 10);
    }

    // Method 3: Find sibling/parent line number element (React view)
    const parentRow = el.closest(".react-code-line");
    if (parentRow) {
      const lineNumEl = parentRow.querySelector(
        LENS_CONFIG.selectors.reactLineNumber
      );
      if (lineNumEl) {
        return parseInt(lineNumEl.textContent, 10);
      }
    }

    // Method 4: Table row structure (legacy view)
    const tableRow = el.closest("tr");
    if (tableRow) {
      const lineNumCell = tableRow.querySelector(
        LENS_CONFIG.selectors.legacyLineNumber
      );
      if (lineNumCell) {
        const num = parseInt(
          lineNumCell.textContent || lineNumCell.dataset?.lineNumber,
          10
        );
        if (!isNaN(num)) return num;
      }
    }

    // Method 5: Count position among siblings
    const parent = el.parentElement;
    if (parent) {
      const siblings = Array.from(parent.children);
      const index = siblings.indexOf(el);
      if (index !== -1) return index + 1;
    }

    return null;
  }

  /**
   * Extract C++ code from the page, preserving empty lines
   */
  function extractCppCode() {
    // Method 1: Hidden textarea (most reliable for React view)
    // This naturally preserves empty lines
    const textarea = document.querySelector(LENS_CONFIG.selectors.codeTextarea);
    if (textarea && textarea.value) {
      console.log("[Lens] Extracted code from textarea, length:", textarea.value.length);
      return textarea.value;
    }

    // Method 2: Collect from rendered line elements
    // Need to be careful to preserve empty lines
    const lineSelectors = [
      LENS_CONFIG.selectors.reactLineContents,
      LENS_CONFIG.selectors.reactLineById,
      LENS_CONFIG.selectors.legacyBlobCode,
    ];

    for (const selector of lineSelectors) {
      const lines = document.querySelectorAll(selector);
      if (lines.length > 0) {
        // Create an array with proper indexing to preserve empty lines
        const codeLines = [];
        
        lines.forEach((el) => {
          const lineNum = getLineNumber(el);
          if (lineNum !== null) {
            // Ensure array is large enough
            while (codeLines.length < lineNum) {
              codeLines.push("");
            }
            // Get text content, treating truly empty elements as empty strings
            const text = el.textContent || "";
            codeLines[lineNum - 1] = text;
          }
        });
        
        console.log("[Lens] Extracted code from DOM elements, lines:", codeLines.length);
        return codeLines.join("\n");
      }
    }

    // Method 3: Pre block (legacy)
    const preBlock = document.querySelector(LENS_CONFIG.selectors.legacyBlobPre);
    if (preBlock) {
      return preBlock.textContent;
    }

    return null;
  }

  /**
   * Get all code line elements currently in the DOM
   */
  function getCodeLineElements() {
    // Try React view selectors first
    let elements = document.querySelectorAll(
      LENS_CONFIG.selectors.reactLineContents
    );
    if (elements.length > 0) return elements;

    elements = document.querySelectorAll(LENS_CONFIG.selectors.reactLineById);
    if (elements.length > 0) return elements;

    // Try legacy view
    elements = document.querySelectorAll(LENS_CONFIG.selectors.legacyBlobCode);
    if (elements.length > 0) return elements;

    return [];
  }

  /**
   * Get the code container element for MutationObserver
   */
  function getCodeContainer() {
    return (
      document.querySelector(LENS_CONFIG.selectors.reactBlobCode) ||
      document.querySelector(LENS_CONFIG.selectors.reactCodeContainer) ||
      document.querySelector(".blob-wrapper")
    );
  }

  // ===========================================================================
  // SELECTION/DRAG INTERCEPTION
  // ===========================================================================

  /**
   * Inject CSS styles to enable text selection when lens is active
   */
  function injectSelectionStyles() {
    // Remove existing style if any
    const existingStyle = document.getElementById("lens-selection-styles");
    if (existingStyle) {
      existingStyle.remove();
    }

    const style = document.createElement("style");
    style.id = "lens-selection-styles";
    style.textContent = `
      /* When lens is active, enable text selection on code */
      .lens-active-container,
      .lens-active-container *,
      .lens-active-container .react-code-line-contents-no-virtualization,
      .lens-active-container [id^="LC"],
      .lens-active-container .blob-code,
      .lens-python-text {
        user-select: text !important;
        -webkit-user-select: text !important;
        -moz-user-select: text !important;
        -ms-user-select: text !important;
        cursor: text !important;
      }

      /* Disable the invisible textarea overlay that GitHub uses */
      .lens-active-container #read-only-cursor-text-area,
      .lens-textarea-disabled {
        pointer-events: none !important;
        user-select: none !important;
        -webkit-user-select: none !important;
        visibility: hidden !important;
        z-index: -1 !important;
      }

      /* Ensure the code container captures pointer events */
      .lens-active-container [data-testid="blob-code"],
      .lens-active-container .react-code-lines,
      .lens-active-container .blob-wrapper {
        pointer-events: auto !important;
        position: relative;
        z-index: 1;
      }

      /* Style for selected Python text */
      .lens-python-text::selection {
        background-color: #3390ff !important;
        color: white !important;
      }

      /* Remove any overlays that might block selection */
      .lens-active-container .react-blob-print-hide,
      .lens-active-container .blob-code-marker-addition,
      .lens-active-container .blob-code-marker-deletion {
        pointer-events: none !important;
      }
    `;
    document.head.appendChild(style);
    console.log("[Lens] Injected selection styles");
  }

  /**
   * Remove the injected selection styles
   */
  function removeSelectionStyles() {
    const style = document.getElementById("lens-selection-styles");
    if (style) {
      style.remove();
      console.log("[Lens] Removed selection styles");
    }
  }

  /**
   * Disable the hidden textarea that GitHub uses for selection
   * This allows our replaced content to be selectable instead
   */
  function disableTextareaSelection() {
    const textarea = document.querySelector(LENS_CONFIG.selectors.codeTextarea);
    if (textarea) {
      // Store original styles
      lensState.originalTextareaStyles = {
        pointerEvents: textarea.style.pointerEvents,
        userSelect: textarea.style.userSelect,
        zIndex: textarea.style.zIndex,
        visibility: textarea.style.visibility,
        className: textarea.className,
      };

      // Add class to disable via CSS (more reliable)
      textarea.classList.add("lens-textarea-disabled");
      
      // Also set inline styles as backup
      textarea.style.pointerEvents = "none";
      textarea.style.userSelect = "none";
      textarea.style.visibility = "hidden";
      textarea.style.zIndex = "-1";
      
      console.log("[Lens] Disabled textarea selection overlay");
    }

    // Also disable any other potential overlay elements
    const overlays = document.querySelectorAll(
      '.react-blob-print-hide, [data-testid="virtual-cursor"]'
    );
    overlays.forEach((el) => {
      el.dataset.lensOriginalPointerEvents = el.style.pointerEvents;
      el.style.pointerEvents = "none";
    });
  }

  /**
   * Restore the textarea selection behavior
   */
  function restoreTextareaSelection() {
    const textarea = document.querySelector(LENS_CONFIG.selectors.codeTextarea);
    if (textarea) {
      textarea.classList.remove("lens-textarea-disabled");
      
      if (lensState.originalTextareaStyles) {
        textarea.style.pointerEvents = lensState.originalTextareaStyles.pointerEvents || "";
        textarea.style.userSelect = lensState.originalTextareaStyles.userSelect || "";
        textarea.style.zIndex = lensState.originalTextareaStyles.zIndex || "";
        textarea.style.visibility = lensState.originalTextareaStyles.visibility || "";
      }
      
      lensState.originalTextareaStyles = null;
      console.log("[Lens] Restored textarea selection overlay");
    }

    // Restore overlay elements
    const overlays = document.querySelectorAll(
      '.react-blob-print-hide, [data-testid="virtual-cursor"]'
    );
    overlays.forEach((el) => {
      if (el.dataset.lensOriginalPointerEvents !== undefined) {
        el.style.pointerEvents = el.dataset.lensOriginalPointerEvents;
        delete el.dataset.lensOriginalPointerEvents;
      }
    });
  }

  /**
   * Make code lines selectable with proper styling
   */
  function enableCodeLineSelection() {
    // Add class to container for CSS targeting
    const container = getCodeContainer();
    if (container) {
      container.classList.add("lens-active-container");
      container.style.userSelect = "text";
      container.style.cursor = "text";
    }

    // Walk up the DOM to ensure parent containers don't block selection
    let parent = container?.parentElement;
    while (parent && parent !== document.body) {
      const computedStyle = window.getComputedStyle(parent);
      if (computedStyle.userSelect === "none") {
        parent.dataset.lensOriginalUserSelect = parent.style.userSelect;
        parent.style.userSelect = "text";
      }
      parent = parent.parentElement;
    }

    // Also ensure each line element is selectable
    const lineElements = getCodeLineElements();
    lineElements.forEach((el) => {
      el.style.userSelect = "text";
      el.style.cursor = "text";
    });

    console.log("[Lens] Enabled code line selection");
  }

  /**
   * Restore original selection behavior on code lines
   */
  function restoreCodeLineSelection() {
    const container = getCodeContainer();
    if (container) {
      container.classList.remove("lens-active-container");
      container.style.userSelect = "";
      container.style.cursor = "";
    }

    // Restore parent container styles
    let parent = container?.parentElement;
    while (parent && parent !== document.body) {
      if (parent.dataset.lensOriginalUserSelect !== undefined) {
        parent.style.userSelect = parent.dataset.lensOriginalUserSelect;
        delete parent.dataset.lensOriginalUserSelect;
      }
      parent = parent.parentElement;
    }

    // Note: individual line styles are restored via innerHTML restoration
    console.log("[Lens] Restored code line selection");
  }

  // ===========================================================================
  // LENS CORE FUNCTIONS
  // ===========================================================================

  /**
   * Apply lens to all visible code lines
   */
  function applyLensToLines() {
    if (!lensState.active || lensState.pythonLines.length === 0) return;

    const lineElements = getCodeLineElements();

    lineElements.forEach((el) => {
      // Skip if already processed
      if (el.hasAttribute("data-lens-applied")) return;

      const lineNum = getLineNumber(el);
      if (lineNum === null || lineNum < 1) return;

      // Store original content if not already stored
      if (!lensState.originalContent.has(el)) {
        lensState.originalContent.set(el, {
          html: el.innerHTML,
          lineNum: lineNum,
        });
      }

      // Get corresponding Python line (0-indexed)
      // Handle both cases: line exists but is empty, or line doesn't exist
      const pythonLine = lensState.pythonLines[lineNum - 1];
      // Preserve empty lines - use empty string for undefined OR empty string
      const displayText = pythonLine !== undefined ? pythonLine : "";

      // Replace content with Python text (including empty lines)
      // Use &nbsp; for empty lines to maintain line height and selectability
      const htmlContent = displayText === "" 
        ? `<span class="lens-python-text" style="color: ${LENS_CONFIG.pythonColor};">&nbsp;</span>`
        : `<span class="lens-python-text" style="color: ${LENS_CONFIG.pythonColor}; user-select: text;">${escapeHtml(displayText)}</span>`;
      
      el.innerHTML = htmlContent;
      el.setAttribute("data-lens-applied", "true");
      el.style.userSelect = "text";
      el.style.cursor = "text";
    });
  }

  /**
   * Update the hidden textarea with Python code
   */
  function updateTextareaContent(pythonCode) {
    const textarea = document.querySelector(LENS_CONFIG.selectors.codeTextarea);
    if (textarea) {
      if (!lensState.originalTextareaValue) {
        lensState.originalTextareaValue = textarea.value;
      }
      textarea.value = pythonCode;
    }
  }

  /**
   * Restore the hidden textarea to original content
   */
  function restoreTextareaContent() {
    const textarea = document.querySelector(LENS_CONFIG.selectors.codeTextarea);
    if (textarea && lensState.originalTextareaValue) {
      textarea.value = lensState.originalTextareaValue;
    }
  }

  /**
   * Activate the lens with Python code
   */
  function activateLens(pythonCode, pythonLines) {
    lensState.active = true;
    lensState.pythonFullCode = pythonCode;
    lensState.pythonLines = pythonLines;

    console.log("[Lens] Activating with", pythonLines.length, "lines");
    console.log("[Lens] Empty lines in Python:", pythonLines.filter(l => l === "").length);

    // Inject CSS styles for text selection
    injectSelectionStyles();

    // Disable the textarea overlay that intercepts selection
    disableTextareaSelection();

    // Apply lens to current visible lines
    applyLensToLines();

    // Enable selection on code lines
    enableCodeLineSelection();

    // Update textarea content (for any remaining clipboard operations)
    updateTextareaContent(pythonCode);

    // Set up MutationObserver to handle GitHub's virtualized scrolling
    setupMutationObserver();

    // Update button state
    updateButtonState();

    console.log("[Lens] Activated - Python code applied to DOM");
  }

  /**
   * Deactivate the lens and restore original content
   */
  function deactivateLens() {
    lensState.active = false;

    // Disconnect observer
    if (lensState.observer) {
      lensState.observer.disconnect();
      lensState.observer = null;
    }

    // Restore all original content
    lensState.originalContent.forEach((data, el) => {
      if (el.isConnected) {
        el.innerHTML = data.html;
        el.removeAttribute("data-lens-applied");
        el.style.userSelect = "";
        el.style.cursor = "";
      }
    });

    // Restore textarea content and selection behavior
    restoreTextareaContent();
    restoreTextareaSelection();
    restoreCodeLineSelection();

    // Remove injected CSS styles
    removeSelectionStyles();

    // Clear state but keep pythonLines for potential re-activation
    lensState.originalContent.clear();
    lensState.originalTextareaValue = "";

    // Update button state
    updateButtonState();

    console.log("[Lens] Deactivated - Original C++ code restored");
  }

  /**
   * Set up MutationObserver to handle dynamic DOM changes
   * GitHub uses virtualized scrolling - lines are added/removed as you scroll
   */
  function setupMutationObserver() {
    if (lensState.observer) {
      lensState.observer.disconnect();
    }

    const container = getCodeContainer();
    if (!container) {
      console.warn("[Lens] Could not find code container for observer");
      return;
    }

    lensState.observer = new MutationObserver((mutations) => {
      if (!lensState.active) return;

      // Check if new nodes were added
      let hasNewNodes = false;
      for (const mutation of mutations) {
        if (mutation.addedNodes.length > 0) {
          hasNewNodes = true;
          break;
        }
      }

      if (hasNewNodes) {
        // Debounce to avoid excessive processing
        requestAnimationFrame(() => {
          applyLensToLines();
        });
      }
    });

    lensState.observer.observe(container, {
      childList: true,
      subtree: true,
    });

    console.log("[Lens] MutationObserver set up on code container");
  }

  // ===========================================================================
  // BACKEND COMMUNICATION
  // ===========================================================================

  /**
   * Send C++ code to backend for conversion via background script
   */
  async function convertCode(cppCode) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { action: "convertCode", code: cppCode },
        (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          if (response && response.success) {
            // Backend returns { python: "...", lines: [...] } in response.data
            const data = response.data;
            
            // Ensure lines array preserves empty lines
            let lines = data.lines;
            if (!lines || lines.length === 0) {
              // Fallback: split the python string by newlines
              lines = data.python.split("\n");
            }
            
            console.log("[Lens] Received", lines.length, "lines from backend");
            console.log("[Lens] First 5 lines:", lines.slice(0, 5));
            
            resolve({
              python: data.python,
              lines: lines,
            });
          } else {
            reject(new Error(response?.error || "Conversion failed"));
          }
        }
      );
    });
  }

  // ===========================================================================
  // UI COMPONENTS
  // ===========================================================================

  /**
   * Update button appearance based on lens state
   */
  function updateButtonState() {
    if (!lensState.button) return;

    if (lensState.isConverting) {
      lensState.button.textContent = "Converting...";
      lensState.button.disabled = true;
      lensState.button.style.backgroundColor = "#9ca3af";
      lensState.button.style.cursor = "wait";
    } else if (lensState.active) {
      lensState.button.textContent = "Show Original (C++)";
      lensState.button.disabled = false;
      lensState.button.style.backgroundColor = LENS_CONFIG.buttonActiveColor;
      lensState.button.style.cursor = "pointer";
    } else {
      lensState.button.textContent = "Convert to Python";
      lensState.button.disabled = false;
      lensState.button.style.backgroundColor = LENS_CONFIG.buttonInactiveColor;
      lensState.button.style.cursor = "pointer";
    }
  }

  /**
   * Handle button click - toggle lens on/off
   */
  async function handleButtonClick() {
    if (lensState.isConverting) return;

    if (lensState.active) {
      // Deactivate lens
      deactivateLens();
    } else {
      // Activate lens
      if (lensState.pythonLines.length > 0) {
        // Already have converted code, just reactivate
        activateLens(lensState.pythonFullCode, lensState.pythonLines);
      } else {
        // Need to fetch conversion from backend
        const cppCode = extractCppCode();
        if (!cppCode) {
          console.error("[Lens] Could not extract C++ code from page");
          alert("Could not extract code from this page.");
          return;
        }

        console.log("[Lens] Extracted C++ code, lines:", cppCode.split("\n").length);

        lensState.isConverting = true;
        updateButtonState();

        try {
          const result = await convertCode(cppCode);
          lensState.isConverting = false;
          activateLens(result.python, result.lines);
        } catch (error) {
          lensState.isConverting = false;
          updateButtonState();
          console.error("[Lens] Conversion error:", error);
          alert(`Conversion failed: ${error.message}`);
        }
      }
    }
  }

  /**
   * Create and inject the floating toggle button
   */
  function createButton() {
    // Remove existing button if any
    const existing = document.getElementById("lens-toggle-button");
    if (existing) {
      existing.remove();
    }

    const button = document.createElement("button");
    button.id = "lens-toggle-button";
    button.textContent = "Convert to Python";

    // Apply styles
    Object.assign(button.style, {
      position: "fixed",
      bottom: "20px",
      right: "20px",
      zIndex: "10000",
      padding: "12px 20px",
      backgroundColor: LENS_CONFIG.buttonInactiveColor,
      color: "white",
      border: "none",
      borderRadius: "8px",
      fontSize: "14px",
      fontWeight: "600",
      cursor: "pointer",
      boxShadow: "0 4px 12px rgba(0, 0, 0, 0.15)",
      transition: "all 0.2s ease",
      fontFamily:
        '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    });

    // Hover effects
    button.addEventListener("mouseenter", () => {
      if (!lensState.isConverting) {
        button.style.transform = "translateY(-2px)";
        button.style.boxShadow = "0 6px 16px rgba(0, 0, 0, 0.2)";
      }
    });

    button.addEventListener("mouseleave", () => {
      button.style.transform = "translateY(0)";
      button.style.boxShadow = "0 4px 12px rgba(0, 0, 0, 0.15)";
    });

    // Click handler
    button.addEventListener("click", handleButtonClick);

    document.body.appendChild(button);
    lensState.button = button;

    console.log("[Lens] Toggle button created");
  }

  // ===========================================================================
  // NAVIGATION HANDLING
  // ===========================================================================

  /**
   * Reset lens state (used when navigating to a new page)
   */
  function resetLensState() {
    if (lensState.active) {
      deactivateLens();
    }
    lensState.pythonLines = [];
    lensState.pythonFullCode = "";
    lensState.originalContent.clear();
    lensState.originalTextareaValue = "";
    lensState.originalTextareaStyles = null;
  }

  /**
   * Initialize or re-initialize the lens for the current page
   */
  function initializeLens() {
    // Reset any existing state
    resetLensState();

    // Check if this is a supported page
    if (!isGitHubBlobPage() || !isCppFile()) {
      // Remove button if it exists
      if (lensState.button) {
        lensState.button.remove();
        lensState.button = null;
      }
      return;
    }

    // Create button if needed
    if (!lensState.button || !lensState.button.isConnected) {
      createButton();
    }

    updateButtonState();
    console.log("[Lens] Initialized for C++ file");
  }

  /**
   * Set up navigation detection for GitHub's SPA
   */
  function setupNavigationDetection() {
    // GitHub uses History API for navigation
    let lastUrl = window.location.href;

    // Check for URL changes periodically (handles all navigation types)
    setInterval(() => {
      if (window.location.href !== lastUrl) {
        lastUrl = window.location.href;
        console.log("[Lens] Navigation detected, reinitializing...");
        // Wait for DOM to settle
        setTimeout(initializeLens, 500);
      }
    }, 500);

    // Also listen for popstate (back/forward buttons)
    window.addEventListener("popstate", () => {
      setTimeout(initializeLens, 500);
    });

    // Listen for turbo navigation events (GitHub uses Turbo)
    document.addEventListener("turbo:load", () => {
      setTimeout(initializeLens, 100);
    });

    document.addEventListener("turbo:render", () => {
      setTimeout(initializeLens, 100);
    });
  }

  // ===========================================================================
  // KEYBOARD SHORTCUTS
  // ===========================================================================

  /**
   * Set up keyboard shortcuts
   */
  function setupKeyboardShortcuts() {
    document.addEventListener("keydown", (e) => {
      // Alt+P to toggle lens
      if (e.altKey && e.key.toLowerCase() === "p") {
        e.preventDefault();
        if (lensState.button && isGitHubBlobPage() && isCppFile()) {
          handleButtonClick();
        }
      }
    });
  }

  // ===========================================================================
  // MAIN INITIALIZATION
  // ===========================================================================

  function main() {
    console.log("[Lens] C++ to Python Lens extension loaded");

    // Initial setup
    initializeLens();

    // Set up navigation detection for GitHub SPA
    setupNavigationDetection();

    // Set up keyboard shortcuts
    setupKeyboardShortcuts();
  }

  // Run when DOM is ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", main);
  } else {
    main();
  }
})();